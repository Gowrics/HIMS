import React, { useContext, useEffect, useState } from "react";
import PageHead from "../Component/PageHead";
import { doctors } from "../assets/ArrayData";
import { useParams } from "react-router";
import { FormContext } from "../FormContext";
import Breadcrumbs from "../Component/BreadCrumbs";

const DocterView = () => {
  const { docterData } = useContext(FormContext);
  const { id } = useParams();
  const [deptDocters, setDeptDocters] = useState([]);
  console.log("selected id", id);
  console.log("select", docterData);

  useEffect(() => {
    if (id) {
      setDeptDocters(
        docterData.filter((docter) => docter.department.deptCode === Number(id))
      );
      console.log(deptDocters);
    } else {
      setDeptDocters(docterData);
    }
  }, [id]);
  if (!deptDocters) {
    setDeptDocters(docterData);
  }
  return (
    <>
      <div className="page-content ">
        <PageHead
          heading="Our Doctor's"
          title="Our Expert Doctor's"
          text="Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo alias earum recusandae ipsa cum? Inventore totam eius expedita sint asperiores eos, corrupti, distinctio fuga reiciendis possimus, dolore labore. Rerum, esse?"
        />
        {deptDocters.length === 0 ? (
          <p>No doctors available for this department.</p>
        ) : (
          <div className="row deptview row-cols-md-3 m-5 g-5 ">
            {deptDocters.map((doctor) => (
              <div className="col slide-up" key={doctor.deptCode}>
                <div className="card">
                  <img
                    src={doctor.drImg} // Make sure to use doctorImg as per your data
                    className="card-img-top"
                    width={"50px"}
                    height={"300px"}
                    alt={doctor.drDesignation}
                  />
                  <div className="card-body">
                    <h5 className="card-title">{doctor.doctorName}</h5>
                    <p className="card-text">{doctor.drDesignation}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
};

export default DocterView;

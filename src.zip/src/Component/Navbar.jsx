import React, { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import logo from "../assets/healthcare.png";
import { UserContext } from "../FormContext";

const Navbar = () => {
  const { setSingleUser, setUserData, singleUser, setUserAuth, UserAuth } =
    useContext(UserContext);
  const [isCollapsed, setIsCollapsed] = useState(true); // Manage collapse state
  const navigate = useNavigate();

  const handleLogout = () => {
    setSingleUser({});
    setUserAuth(false);
    navigate("/");
    setUserData({
      username: "",
      password: "",
    });
    console.log("logout", singleUser);
  };

  const handleMenuCollapse = () => {
    setIsCollapsed(true); // Collapse menu after click
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark fixed-top ">
      <div className="container">
        <Link className="navbar-brand" to="/">
          <img
            src={logo}
            alt="Brand Logo"
            style={{ height: "40px", width: "60px" }}
          />
          <h1>HIMS</h1>
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded={isCollapsed ? "false" : "true"} // Toggle the expanded state
          aria-label="Toggle navigation"
          onClick={() => setIsCollapsed(!isCollapsed)} // Toggle collapse on button click
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div
          className={`collapse navbar-collapse ${isCollapsed ? "" : "show"}`}
          id="navbarNav"
        >
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <Link
                className="nav-link text-white"
                to="/"
                onClick={handleMenuCollapse}
              >
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link
                className="nav-link text-white"
                to="/departmentview"
                onClick={handleMenuCollapse}
              >
                Departments
              </Link>
            </li>
            <li className="nav-item">
              <Link
                className="nav-link text-white"
                to="/docterview"
                onClick={handleMenuCollapse}
              >
                Doctors
              </Link>
            </li>
            {UserAuth ? (
              <li className="nav-item dropdown">
                <Link
                  className="nav-link dropdown-toggle text-white"
                  to="#"
                  id="servicesDropdown"
                  role="button"
                  aria-expanded="false"
                >
                  Services
                </Link>
                <ul
                  className="dropdown-menu"
                  aria-labelledby="servicesDropdown"
                >
                  <li>
                    <Link
                      className="dropdown-item"
                      to="/nationality"
                      onClick={handleMenuCollapse}
                    >
                      Nationality
                    </Link>
                  </li>
                  <li>
                    <Link
                      className="dropdown-item"
                      to="/department"
                      onClick={handleMenuCollapse}
                    >
                      Departments
                    </Link>
                  </li>
                  <li>
                    <Link
                      className="dropdown-item"
                      to="/docters"
                      onClick={handleMenuCollapse}
                    >
                      Doctors
                    </Link>
                  </li>
                </ul>
              </li>
            ) : (
              <div></div>
            )}
            <li className="nav-item">
              <Link
                className="nav-link text-white"
                to="/about"
                onClick={handleMenuCollapse}
              >
                About
              </Link>
            </li>
          </ul>
        </div>

        <div className="ms-5">
          {singleUser && Object.keys(singleUser).length > 0 ? (
            <button
              className="btn btn-primary ms-1 btn-block"
              onClick={handleLogout}
            >
              Sign Out
            </button>
          ) : (
            <Link
              className="btn text-light"
              style={{ backgroundColor: "#122738 " }}
              to="/signin"
            >
              Sign In
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
